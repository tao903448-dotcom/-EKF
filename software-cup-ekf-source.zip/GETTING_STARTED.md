# 快速开始指南

## 前置条件

### 1. 安装GCC编译器

**Windows用户：**
1. 下载 MinGW-w64：https://www.mingw-w64.org/
2. 安装时选择：
   - Architecture: x86_64
   - Threads: posix
   - Exception: seh
3. 将 `C:\mingw64\bin` 添加到系统PATH环境变量

**验证安装：**
```bash
gcc --version
```

### 2. 安装Git（可选）
- 下载：https://git-scm.com/
- 用于版本控制

## 构建项目

### Windows系统

1. 打开命令提示符或PowerShell
2. 进入项目目录：
   ```bash
   cd C:\Users\ZHOUTAO\software-cup-ekf
   ```
3. 运行构建脚本：
   ```bash
   build.bat
   ```

### Linux/Mac系统

1. 打开终端
2. 进入项目目录
3. 运行构建命令：
   ```bash
   make lib
   make tests
   ```

## 运行测试

### 矩阵运算测试
```bash
# Windows
build\test_matrix.exe

# Linux/Mac
./build/test_matrix
```

**预期输出：**
```
========== 矩阵运算库测试 ==========

PASS: 矩阵初始化测试
PASS: 单位矩阵测试
PASS: 矩阵加法测试
PASS: 矩阵乘法测试
PASS: 矩阵转置测试
PASS: 矩阵求逆测试
PASS: 矩阵行列式测试
PASS: Cholesky分解测试

========== 测试结果 ==========
通过: 8
失败: 0
总计: 8
```

### EKF演示程序
```bash
# Windows
build\ekf_demo.exe

# Linux/Mac
./build/ekf_demo
```

**预期输出：**
```
========== EKF演示程序 ==========
场景：一维位置跟踪

步数    真实位置    观测位置    估计位置    估计速度
----    --------    --------    --------    --------
0       0.100       0.234       0.156       0.987
10      1.100       1.234       1.156       1.023
20      2.100       2.089       2.112       0.998
...
```

## 项目结构说明

```
software-cup-ekf/
├── include/              # 头文件
│   ├── matrix.h         # 矩阵运算库接口
│   └── ekf.h            # EKF框架接口
├── src/                 # 源代码
│   ├── matrix.c         # 矩阵运算库实现
│   └── ekf.c            # EKF框架实现
├── tests/               # 测试代码
│   └── test_matrix.c    # 矩阵运算测试
├── examples/            # 示例程序
│   └── ekf_demo.c       # EKF演示
├── docs/                # 文档
│   └── DEVELOPMENT_STATUS.md  # 开发状态
├── build/               # 编译输出（自动创建）
├── lib/                 # 库文件（自动创建）
├── Makefile             # Linux/Mac构建脚本
├── build.bat            # Windows构建脚本
└── README.md            # 项目说明
```

## 下一步开发

### 1. 理解代码
- 阅读 `include/matrix.h` 了解矩阵运算接口
- 阅读 `include/ekf.h` 了解EKF框架接口
- 查看 `examples/ekf_demo.c` 学习使用方法

### 2. 修改和扩展
- 调整矩阵维度：修改 `matrix.h` 中的 `MATRIX_MAX_ROWS` 和 `MATRIX_MAX_COLS`
- 添加新的状态模型：在 `ekf_demo.c` 中修改状态转移函数
- 实现自定义观测模型：修改观测函数

### 3. 性能优化
- 启用ARM NEON优化（需要ARM平台）
- 调整编译器优化选项
- 减少临时矩阵使用

## 常见问题

### Q: 编译时出现"undefined reference to `matrix_init`"
**A:** 确保先编译库文件，再编译测试程序：
```bash
make lib
make tests
```

### Q: 运行测试时出现"FAIL"
**A:** 检查：
1. 编译器是否正确安装
2. 是否使用了正确的编译选项
3. 代码是否有修改

### Q: 如何添加新的矩阵运算？
**A:** 
1. 在 `include/matrix.h` 中添加函数声明
2. 在 `src/matrix.c` 中实现函数
3. 在 `tests/test_matrix.c` 中添加测试用例

### Q: 如何调整EKF参数？
**A:** 在 `ekf_demo.c` 中修改：
- 过程噪声 `Q`
- 观测噪声 `R`
- 初始状态 `x0`
- 初始协方差 `P0`

## 调试技巧

### 1. 启用调试信息
```bash
make debug
```

### 2. 使用printf调试
在关键位置添加打印语句：
```c
matrix_print(&mat, "Matrix Name");
```

### 3. 检查矩阵维度
确保矩阵运算维度匹配：
- 加法/减法：维度必须相同
- 乘法：A的列数 = B的行数
- 求逆：必须是方阵

## 性能基准

### 矩阵运算性能（参考）
- 3x3矩阵乘法：< 1μs
- 3x3矩阵求逆：< 5μs
- EKF更新（2维状态）：< 10μs

### 内存使用
- 矩阵结构体：~1KB
- EKF状态：~10KB
- 总内存：~50KB

## 获取帮助

### 文档
- `README.md` - 项目概述
- `docs/DEVELOPMENT_STATUS.md` - 开发状态
- `GETTING_STARTED.md` - 本文档

### 代码注释
所有源文件都有详细的Doxygen风格注释

### 调试输出
使用 `matrix_print()` 函数打印矩阵内容

## 提交代码

### 1. 添加文件
```bash
git add .
```

### 2. 提交更改
```bash
git commit -m "描述你的更改"
```

### 3. 推送（如果配置了远程仓库）
```bash
git push origin main
```

## 联系方式

如有问题，请联系开发团队。

---

**最后更新：** 2026年6月11日