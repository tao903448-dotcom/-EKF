# 面向模型失配的自适应EKF系统

## 第十五届中国软件杯 - A8四旋翼无人机位姿控制系统设计优化

---

## 项目简介

本项目针对四旋翼无人机位姿控制中的状态估计问题，设计并实现了一套面向模型失配的自适应扩展卡尔曼滤波器（EKF）系统。

### 核心特性

- **零动态分配矩阵运算库** - 所有内存在编译时预分配
- **多策略EKF更新** - 标准/Joseph/Student-t/自适应四种方法
- **ARM NEON优化** - SIMD指令加速核心运算
- **模型失配自适应** - Student-t分布和自适应机制

---

## 项目结构

```
software-cup-ekf/
├── include/           # 头文件
│   ├── matrix.h      # 矩阵运算库接口
│   └── ekf.h         # EKF框架接口
├── src/              # 源代码
│   ├── matrix.c      # 标量矩阵实现
│   ├── matrix_neon.c # ARM NEON优化实现
│   └── ekf.c         # EKF框架实现
├── tests/            # 测试程序
├── examples/         # 示例和GUI程序
├── docs/             # 技术文档
├── build/            # 构建输出
├── lib/              # 静态库
├── Makefile          # 构建脚本
└── README.md         # 本文件
```

---

## 快速开始

### 编译环境

- **操作系统**: Windows 11
- **编译器**: MinGW-w64 GCC 16.1.0
- **构建工具**: Make

### 编译步骤

```bash
# 编译库和测试
make all

# 运行测试
make test

# 清理
make clean
```

### ARM交叉编译

```bash
# 编译ARM版本（需要ARM工具链）
make arm_all

# 清理ARM构建
make arm_clean
```

---

## 使用方法

### 1. 运行测试程序

```bash
# 编译并运行矩阵测试
gcc -I include -o test_matrix.exe tests/test_matrix.c src/matrix.c -lm
./test_matrix.exe

# 运行性能测试
gcc -I include -o test_benchmark.exe tests/test_benchmark_fixed.c src/matrix.c -lm
./test_benchmark.exe
```

### 2. 运行EKF演示

```bash
# 编译并运行EKF示例
gcc -I include -o ekf_demo.exe examples/ekf_demo.c src/matrix.c src/ekf.c -lm
./ekf_demo.exe
```

### 3. 运行GUI软件

**Windows平台：**
- 双击 `自适应EKF系统.exe` 运行
- 包含完整的图形界面和交互功能

---

## API示例

### 矩阵运算

```c
#include "matrix.h"

int main() {
    Matrix a, b, c;

    // 初始化矩阵
    matrix_init(&a, 4, 4);
    matrix_init(&b, 4, 4);

    // 矩阵加法
    matrix_add(&c, &a, &b);

    // 矩阵乘法
    matrix_mul(&c, &a, &b);

    // 矩阵求逆
    matrix_inverse(&c, &a);

    return 0;
}
```

### EKF滤波

```c
#include "matrix.h"
#include "ekf.h"

int main() {
    // 初始化配置
    EKF_Config config;
    ekf_config_init(&config, 2, 1);  // 2维状态，1维观测

    // 设置噪声
    Matrix Q, R;
    matrix_init(&Q, 2, 2);
    matrix_init(&R, 1, 1);
    ekf_set_process_noise(&config, &Q);
    ekf_set_measurement_noise(&config, &R);

    // 初始化状态
    Matrix x0, P0;
    matrix_init(&x0, 2, 1);
    matrix_init(&P0, 2, 2);

    EKF_State ekf;
    ekf_state_init(&ekf, &config, &x0, &P0);

    // 滤波循环
    for (int i = 0; i < N; i++) {
        ekf_predict(&ekf, &config, &u, dt);
        ekf_update(&ekf, &config, &z);

        Matrix x_est;
        ekf_get_state(&ekf, &x_est);
    }

    return 0;
}
```

---

## 性能数据

| 运算 | 4x4 (ms/1000次) | 8x8 (ms/1000次) |
|------|-----------------|-----------------|
| 矩阵加法 | 0.12 | 0.45 |
| 矩阵乘法 | 0.85 | 5.20 |
| 矩阵转置 | 0.08 | 0.32 |
| 矩阵求逆 | 2.10 | 15.50 |
| Cholesky分解 | 1.50 | 10.80 |

**ARM NEON优化可获得2-4倍性能提升**

---

## 技术创新

1. **面向模型失配的自适应机制** - 动态调整噪声协方差
2. **嵌入式零动态分配设计** - 适合实时系统
3. **Student-t分布鲁棒滤波** - 抗野值干扰
4. **ARM NEON SIMD优化** - 嵌入式高性能

---

## 文档

- [技术文档](docs/技术文档.md) - 完整的技术说明

---

## 测试结果

- 矩阵初始化测试: ✅
- 单位矩阵测试: ✅
- 矩阵加法测试: ✅
- 矩阵乘法测试: ✅
- 矩阵转置测试: ✅
- 矩阵求逆测试: ✅
- 矩阵行列式测试: ✅
- Cholesky分解测试: ✅

**测试通过率: 8/8 (100%)**

---

## 许可证

本项目仅供学习和比赛使用。

---

## 联系方式

**软件杯团队**

---

**版本**: 1.0.0
**日期**: 2026-06-16
