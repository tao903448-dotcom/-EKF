/**
 * @file test_ekf.c
 * @brief EKF框架单元测试
 *
 * 测试EKF框架的各项功能：
 * - 配置初始化
 * - 状态初始化
 * - 预测步骤
 * - 更新步骤
 * - 状态获取
 *
 * @author 软件杯团队
 * @date 2026-06-16
 */

#include "matrix.h"
#include "ekf.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

/* 测试计数 */
static int test_passed = 0;
static int test_failed = 0;

/* 辅助宏 */
#define TEST_ASSERT(condition, msg) \
    do { \
        if (condition) { \
            printf("  PASS: %s\n", msg); \
            test_passed++; \
        } else { \
            printf("  FAIL: %s\n", msg); \
            test_failed++; \
        } \
    } while(0)

/* ========== 测试函数 ========== */

/**
 * @brief 简单的一维位置跟踪状态函数
 */
static bool test_state_func(const Matrix *x, const Matrix *u, Matrix *x_new, float dt) {
    float pos = matrix_get(x, 0, 0);
    float vel = matrix_get(x, 1, 0);
    matrix_set(x_new, 0, 0, pos + vel * dt);
    matrix_set(x_new, 1, 0, vel);
    return true;
}

/**
 * @brief 简单的观测函数
 */
static bool test_meas_func(const Matrix *x, Matrix *z) {
    matrix_set(z, 0, 0, matrix_get(x, 0, 0));
    return true;
}

/**
 * @brief 简单的状态雅可比函数
 */
static bool test_state_jacob(const Matrix *x, const Matrix *u, Matrix *F, float dt) {
    matrix_set(F, 0, 0, 1.0f);
    matrix_set(F, 0, 1, dt);
    matrix_set(F, 1, 0, 0.0f);
    matrix_set(F, 1, 1, 1.0f);
    return true;
}

/**
 * @brief 简单的观测雅可比函数
 */
static bool test_meas_jacob(const Matrix *x, Matrix *H) {
    matrix_set(H, 0, 0, 1.0f);
    matrix_set(H, 0, 1, 0.0f);
    return true;
}

/**
 * @brief 测试EKF配置初始化
 */
static void test_ekf_config_init(void) {
    printf("\nTest: EKF Config Init\n");

    EKF_Config config;
    bool result = ekf_config_init(&config, 2, 1);

    TEST_ASSERT(result == true, "Config init success");
    TEST_ASSERT(config.state_dim == 2, "State dimension = 2");
    TEST_ASSERT(config.measurement_dim == 1, "Measurement dimension = 1");
    TEST_ASSERT(config.update_method == EKF_UPDATE_STANDARD, "Default update method = STANDARD");
    TEST_ASSERT(config.student_t_nu == 5.0f, "Default Student-t nu = 5.0");
    TEST_ASSERT(config.adaptive_window == 50.0f, "Default adaptive window = 50.0");
}

/**
 * @brief 测试EKF函数设置
 */
static void test_ekf_set_functions(void) {
    printf("\nTest: EKF Set Functions\n");

    EKF_Config config;
    ekf_config_init(&config, 2, 1);

    ekf_set_functions(&config, test_state_func, test_meas_func,
                      test_state_jacob, test_meas_jacob);

    TEST_ASSERT(config.state_func == test_state_func, "State function set");
    TEST_ASSERT(config.measurement_func == test_meas_func, "Measurement function set");
    TEST_ASSERT(config.state_jacobian_func == test_state_jacob, "State Jacobian set");
    TEST_ASSERT(config.measurement_jacobian_func == test_meas_jacob, "Measurement Jacobian set");
}

/**
 * @brief 测试噪声设置
 */
static void test_ekf_noise(void) {
    printf("\nTest: EKF Noise Setting\n");

    EKF_Config config;
    ekf_config_init(&config, 2, 1);

    Matrix Q, R;
    matrix_init(&Q, 2, 2);
    matrix_init(&R, 1, 1);

    matrix_set(&Q, 0, 0, 0.1f);
    matrix_set(&Q, 1, 1, 0.2f);
    matrix_set(&R, 0, 0, 1.0f);

    bool q_result = ekf_set_process_noise(&config, &Q);
    bool r_result = ekf_set_measurement_noise(&config, &R);

    TEST_ASSERT(q_result == true, "Process noise set successfully");
    TEST_ASSERT(r_result == true, "Measurement noise set successfully");
    TEST_ASSERT(config.Q.data[0] == 0.1f, "Q[0][0] = 0.1");
    TEST_ASSERT(config.R.data[0] == 1.0f, "R[0][0] = 1.0");
}

/**
 * @brief 测试EKF状态初始化
 */
static void test_ekf_state_init(void) {
    printf("\nTest: EKF State Init\n");

    EKF_Config config;
    ekf_config_init(&config, 2, 1);
    ekf_set_functions(&config, test_state_func, test_meas_func,
                      test_state_jacob, test_meas_jacob);

    Matrix x0, P0;
    matrix_init(&x0, 2, 1);
    matrix_init(&P0, 2, 2);
    matrix_set(&x0, 0, 0, 0.0f);
    matrix_set(&x0, 1, 0, 1.0f);
    matrix_set(&P0, 0, 0, 1.0f);
    matrix_set(&P0, 1, 1, 1.0f);

    EKF_State ekf;
    bool result = ekf_state_init(&ekf, &config, &x0, &P0);

    TEST_ASSERT(result == true, "EKF state init success");
    TEST_ASSERT(ekf.initialized == true, "EKF initialized flag set");
    TEST_ASSERT(ekf.step_count == 0, "Step count = 0");
}

/**
 * @brief 测试EKF预测步骤
 */
static void test_ekf_predict(void) {
    printf("\nTest: EKF Predict\n");

    EKF_Config config;
    ekf_config_init(&config, 2, 1);
    ekf_set_functions(&config, test_state_func, test_meas_func,
                      test_state_jacob, test_meas_jacob);

    Matrix Q, R;
    matrix_init(&Q, 2, 2);
    matrix_init(&R, 1, 1);
    matrix_set(&Q, 0, 0, 0.1f);
    matrix_set(&Q, 1, 1, 0.1f);
    matrix_set(&R, 0, 0, 1.0f);
    ekf_set_process_noise(&config, &Q);
    ekf_set_measurement_noise(&config, &R);

    Matrix x0, P0;
    matrix_init(&x0, 2, 1);
    matrix_init(&P0, 2, 2);
    matrix_set(&x0, 0, 0, 0.0f);
    matrix_set(&x0, 1, 0, 1.0f);
    matrix_set(&P0, 0, 0, 1.0f);
    matrix_set(&P0, 1, 1, 1.0f);

    EKF_State ekf;
    ekf_state_init(&ekf, &config, &x0, &P0);

    Matrix u;
    matrix_init(&u, 1, 1);

    bool result = ekf_predict(&ekf, &config, &u, 1.0f);

    TEST_ASSERT(result == true, "Predict step success");
    TEST_ASSERT(ekf.step_count == 1, "Step count incremented");
}

/**
 * @brief 测试EKF更新步骤
 */
static void test_ekf_update(void) {
    printf("\nTest: EKF Update\n");

    EKF_Config config;
    ekf_config_init(&config, 2, 1);
    ekf_set_functions(&config, test_state_func, test_meas_func,
                      test_state_jacob, test_meas_jacob);

    Matrix Q, R;
    matrix_init(&Q, 2, 2);
    matrix_init(&R, 1, 1);
    matrix_set(&Q, 0, 0, 0.1f);
    matrix_set(&Q, 1, 1, 0.1f);
    matrix_set(&R, 0, 0, 1.0f);
    ekf_set_process_noise(&config, &Q);
    ekf_set_measurement_noise(&config, &R);

    Matrix x0, P0;
    matrix_init(&x0, 2, 1);
    matrix_init(&P0, 2, 2);
    matrix_set(&x0, 0, 0, 0.0f);
    matrix_set(&x0, 1, 0, 1.0f);
    matrix_set(&P0, 0, 0, 1.0f);
    matrix_set(&P0, 1, 1, 1.0f);

    EKF_State ekf;
    ekf_state_init(&ekf, &config, &x0, &P0);

    Matrix u;
    matrix_init(&u, 1, 1);
    ekf_predict(&ekf, &config, &u, 1.0f);

    Matrix z;
    matrix_init(&z, 1, 1);
    matrix_set(&z, 0, 0, 1.5f);  /* 观测值 */

    bool result = ekf_update(&ekf, &config, &z);

    TEST_ASSERT(result == true, "Update step success");

    /* 获取估计值 */
    Matrix x_est;
    matrix_init(&x_est, 2, 1);
    ekf_get_state(&ekf, &x_est);

    float est_pos = matrix_get(&x_est, 0, 0);
    TEST_ASSERT(est_pos > 0.0f && est_pos < 2.0f, "Position estimate reasonable");
}

/**
 * @brief 测试EKF完整流程
 */
static void test_ekf_full_cycle(void) {
    printf("\nTest: EKF Full Cycle\n");

    EKF_Config config;
    ekf_config_init(&config, 2, 1);
    ekf_set_functions(&config, test_state_func, test_meas_func,
                      test_state_jacob, test_meas_jacob);

    Matrix Q, R;
    matrix_init(&Q, 2, 2);
    matrix_init(&R, 1, 1);
    matrix_set(&Q, 0, 0, 0.1f);
    matrix_set(&Q, 1, 1, 0.1f);
    matrix_set(&R, 0, 0, 1.0f);
    ekf_set_process_noise(&config, &Q);
    ekf_set_measurement_noise(&config, &R);

    Matrix x0, P0;
    matrix_init(&x0, 2, 1);
    matrix_init(&P0, 2, 2);
    matrix_set(&x0, 0, 0, 0.0f);
    matrix_set(&x0, 1, 0, 1.0f);
    matrix_set(&P0, 0, 0, 1.0f);
    matrix_set(&P0, 1, 1, 1.0f);

    EKF_State ekf;
    ekf_state_init(&ekf, &config, &x0, &P0);

    Matrix u;
    matrix_init(&u, 1, 1);

    /* 运行10步 */
    float true_pos = 0.0f;
    float velocity = 1.0f;
    float mse = 0.0f;

    for (int i = 0; i < 10; i++) {
        true_pos += velocity;
        float obs = true_pos + ((float)rand() / RAND_MAX - 0.5f) * 0.5f;

        ekf_predict(&ekf, &config, &u, 1.0f);

        Matrix z;
        matrix_init(&z, 1, 1);
        matrix_set(&z, 0, 0, obs);
        ekf_update(&ekf, &config, &z);

        Matrix x_est;
        matrix_init(&x_est, 2, 1);
        ekf_get_state(&ekf, &x_est);
        float est = matrix_get(&x_est, 0, 0);

        float error = est - true_pos;
        mse += error * error;
    }

    mse /= 10.0f;

    TEST_ASSERT(ekf.step_count == 10, "Completed 10 steps");
    TEST_ASSERT(mse < 1.0f, "MSE < 1.0 (converged)");
}

/**
 * @brief 测试不同更新方法
 */
static void test_ekf_update_methods(void) {
    printf("\nTest: EKF Update Methods\n");

    EKF_Config config;
    ekf_config_init(&config, 2, 1);
    ekf_set_functions(&config, test_state_func, test_meas_func,
                      test_state_jacob, test_meas_jacob);

    Matrix Q, R;
    matrix_init(&Q, 2, 2);
    matrix_init(&R, 1, 1);
    matrix_set(&Q, 0, 0, 0.1f);
    matrix_set(&Q, 1, 1, 0.1f);
    matrix_set(&R, 0, 0, 1.0f);
    ekf_set_process_noise(&config, &Q);
    ekf_set_measurement_noise(&config, &R);

    /* 测试标准更新 */
    ekf_set_update_method(&config, EKF_UPDATE_STANDARD);
    TEST_ASSERT(config.update_method == EKF_UPDATE_STANDARD, "Standard update method set");

    /* 测试Joseph更新 */
    ekf_set_update_method(&config, EKF_UPDATE_JOSEPH);
    TEST_ASSERT(config.update_method == EKF_UPDATE_JOSEPH, "Joseph update method set");

    /* 测试Student-t更新 */
    ekf_set_update_method(&config, EKF_UPDATE_STUDENT_T);
    TEST_ASSERT(config.update_method == EKF_UPDATE_STUDENT_T, "Student-t update method set");

    /* 测试自适应更新 */
    ekf_set_update_method(&config, EKF_UPDATE_ADAPTIVE);
    TEST_ASSERT(config.update_method == EKF_UPDATE_ADAPTIVE, "Adaptive update method set");
}

/* ========== 主函数 ========== */

int main(void) {
    printf("╔══════════════════════════════════════════════════════════╗\n");
    printf("║              EKF框架单元测试                             ║\n");
    printf("║              面向模型失配的自适应EKF系统                   ║\n");
    printf("╚══════════════════════════════════════════════════════════╝\n");

    /* 运行测试 */
    test_ekf_config_init();
    test_ekf_set_functions();
    test_ekf_noise();
    test_ekf_state_init();
    test_ekf_predict();
    test_ekf_update();
    test_ekf_full_cycle();
    test_ekf_update_methods();

    /* 打印结果 */
    printf("\n══════════════════════════════════════════════════════════\n");
    printf("测试结果:\n");
    printf("  通过: %d\n", test_passed);
    printf("  失败: %d\n", test_failed);
    printf("  总计: %d\n", test_passed + test_failed);
    printf("══════════════════════════════════════════════════════════\n");

    return test_failed > 0 ? 1 : 0;
}
