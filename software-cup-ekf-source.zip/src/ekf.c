/**
 * @file ekf.c
 * @brief 扩展卡尔曼滤波器（EKF）实现
 *
 * 实现自适应EKF系统，包含：
 * - 标准EKF预测和更新
 * - Joseph形式协方差更新
 * - Student-t鲁棒更新
 * - 自适应噪声估计
 *
 * @author 软件杯团队
 * @date 2026-06-11
 */

#include "ekf.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* 内部辅助函数 */
static bool ekf_standard_update(EKF_State *state, const EKF_Config *config);
static bool ekf_joseph_update(EKF_State *state, const EKF_Config *config);
static bool ekf_student_t_update(EKF_State *state, const EKF_Config *config);
static bool ekf_adaptive_update(EKF_State *state, const EKF_Config *config);
static float ekf_mahalanobis_distance(const EKF_State *state);

/* ========== 配置函数 ========== */

bool ekf_config_init(EKF_Config *config, uint8_t state_dim, uint8_t measurement_dim) {
    if (config == NULL || state_dim == 0 || measurement_dim == 0 ||
        state_dim > EKF_MAX_STATE_DIM || measurement_dim > EKF_MAX_MEASUREMENT_DIM) {
        return false;
    }

    config->state_dim = state_dim;
    config->measurement_dim = measurement_dim;
    config->update_method = EKF_UPDATE_STANDARD;

    /* 初始化函数指针为NULL */
    config->state_func = NULL;
    config->measurement_func = NULL;
    config->state_jacobian_func = NULL;
    config->measurement_jacobian_func = NULL;

    /* 初始化噪声矩阵 */
    matrix_zeros(&config->Q, state_dim, state_dim);
    matrix_zeros(&config->R, measurement_dim, measurement_dim);

    /* 设置默认Student-t参数 */
    config->student_t_nu = 5.0f;     /* 自由度 */
    config->student_t_delta = 1.0f;  /* 尺度参数 */

    /* 设置默认自适应参数 */
    config->adaptive_window = 50.0f;
    config->adaptive_factor = 0.95f;

    return true;
}

void ekf_set_functions(EKF_Config *config,
                      EKF_StateFunc state_func,
                      EKF_MeasurementFunc measurement_func,
                      EKF_StateJacobianFunc state_jacobian,
                      EKF_MeasurementJacobianFunc measurement_jacobian) {
    if (config != NULL) {
        config->state_func = state_func;
        config->measurement_func = measurement_func;
        config->state_jacobian_func = state_jacobian;
        config->measurement_jacobian_func = measurement_jacobian;
    }
}

bool ekf_set_process_noise(EKF_Config *config, const Matrix *Q) {
    if (config == NULL || Q == NULL) {
        return false;
    }

    if (Q->rows != config->state_dim || Q->cols != config->state_dim) {
        return false;
    }

    return matrix_copy(&config->Q, Q);
}

bool ekf_set_measurement_noise(EKF_Config *config, const Matrix *R) {
    if (config == NULL || R == NULL) {
        return false;
    }

    if (R->rows != config->measurement_dim || R->cols != config->measurement_dim) {
        return false;
    }

    return matrix_copy(&config->R, R);
}

void ekf_set_student_t_params(EKF_Config *config, float nu, float delta) {
    if (config != NULL) {
        config->student_t_nu = nu;
        config->student_t_delta = delta;
    }
}

void ekf_set_adaptive_params(EKF_Config *config, float window_size, float factor) {
    if (config != NULL) {
        config->adaptive_window = window_size;
        config->adaptive_factor = factor;
    }
}

void ekf_set_update_method(EKF_Config *config, EKF_UpdateMethod method) {
    if (config != NULL) {
        config->update_method = method;
    }
}

/* ========== 状态函数 ========== */

bool ekf_state_init(EKF_State *state, const EKF_Config *config,
                   const Matrix *x0, const Matrix *P0) {
    if (state == NULL || config == NULL || x0 == NULL || P0 == NULL) {
        return false;
    }

    if (x0->rows != config->state_dim || x0->cols != 1) {
        return false;
    }

    if (P0->rows != config->state_dim || P0->cols != config->state_dim) {
        return false;
    }

    /* 初始化状态向量和协方差 */
    matrix_copy(&state->x, x0);
    matrix_copy(&state->P, P0);

    /* 初始化其他矩阵 */
    matrix_zeros(&state->S, config->measurement_dim, config->measurement_dim);
    matrix_zeros(&state->K, config->state_dim, config->measurement_dim);
    matrix_zeros(&state->y, config->measurement_dim, 1);
    matrix_zeros(&state->z, config->measurement_dim, 1);
    matrix_zeros(&state->z_pred, config->measurement_dim, 1);

    /* 初始化临时矩阵 */
    matrix_zeros(&state->F, config->state_dim, config->state_dim);
    matrix_zeros(&state->H, config->measurement_dim, config->state_dim);
    matrix_zeros(&state->P_pred, config->state_dim, config->state_dim);
    matrix_zeros(&state->temp1, config->state_dim, config->state_dim);
    matrix_zeros(&state->temp2, config->state_dim, config->state_dim);

    state->initialized = true;
    state->step_count = 0;

    return true;
}

bool ekf_predict(EKF_State *state, const EKF_Config *config,
                const Matrix *u, float dt) {
    if (state == NULL || config == NULL || !state->initialized) {
        return false;
    }

    if (config->state_func == NULL || config->state_jacobian_func == NULL) {
        return false;
    }

    /* 1. 状态预测: x = f(x, u, dt) */
    if (!config->state_func(&state->x, u, &state->x, dt)) {
        return false;
    }

    /* 2. 计算状态转移雅可比矩阵: F = df/dx */
    if (!config->state_jacobian_func(&state->x, u, &state->F, dt)) {
        return false;
    }

    /* 3. 协方差预测: P = F * P * F' + Q */
    /* 计算 F * P */
    if (!matrix_mul(&state->temp1, &state->F, &state->P)) {
        return false;
    }

    /* 计算 F' */
    Matrix F_T;
    if (!matrix_transpose(&F_T, &state->F)) {
        return false;
    }

    /* 计算 F * P * F' */
    if (!matrix_mul(&state->temp2, &state->temp1, &F_T)) {
        return false;
    }

    /* 计算 P = F * P * F' + Q */
    if (!matrix_add(&state->P_pred, &state->temp2, &config->Q)) {
        return false;
    }

    /* 更新协方差 */
    matrix_copy(&state->P, &state->P_pred);

    state->step_count++;
    return true;
}

bool ekf_update(EKF_State *state, const EKF_Config *config, const Matrix *z) {
    if (state == NULL || config == NULL || z == NULL || !state->initialized) {
        return false;
    }

    if (config->measurement_func == NULL || config->measurement_jacobian_func == NULL) {
        return false;
    }

    /* 保存观测值 */
    matrix_copy(&state->z, z);

    /* 1. 计算预测观测: z_pred = h(x) */
    if (!config->measurement_func(&state->x, &state->z_pred)) {
        return false;
    }

    /* 2. 计算观测雅可比矩阵: H = dh/dx */
    if (!config->measurement_jacobian_func(&state->x, &state->H)) {
        return false;
    }

    /* 3. 计算新息: y = z - z_pred */
    if (!matrix_sub(&state->y, &state->z, &state->z_pred)) {
        return false;
    }

    /* 4. 根据更新方法执行更新 */
    switch (config->update_method) {
        case EKF_UPDATE_STANDARD:
            return ekf_standard_update(state, config);

        case EKF_UPDATE_JOSEPH:
            return ekf_joseph_update(state, config);

        case EKF_UPDATE_STUDENT_T:
            return ekf_student_t_update(state, config);

        case EKF_UPDATE_ADAPTIVE:
            return ekf_adaptive_update(state, config);

        default:
            return false;
    }
}

/* ========== 标准卡尔曼更新 ========== */

static bool ekf_standard_update(EKF_State *state, const EKF_Config *config) {
    /* 1. 计算新息协方差: S = H * P * H' + R */
    Matrix H_T;
    if (!matrix_transpose(&H_T, &state->H)) {
        return false;
    }

    /* H * P */
    if (!matrix_mul(&state->temp1, &state->H, &state->P)) {
        return false;
    }

    /* H * P * H' */
    if (!matrix_mul(&state->temp2, &state->temp1, &H_T)) {
        return false;
    }

    /* S = H * P * H' + R */
    if (!matrix_add(&state->S, &state->temp2, &config->R)) {
        return false;
    }

    /* 2. 计算卡尔曼增益: K = P * H' * S^(-1) */
    Matrix S_inv;
    if (!matrix_inverse(&S_inv, &state->S)) {
        return false;
    }

    /* P * H' */
    if (!matrix_mul(&state->temp1, &state->P, &H_T)) {
        return false;
    }

    /* K = P * H' * S^(-1) */
    if (!matrix_mul(&state->K, &state->temp1, &S_inv)) {
        return false;
    }

    /* 3. 状态更新: x = x + K * y */
    if (!matrix_mul(&state->temp1, &state->K, &state->y)) {
        return false;
    }

    if (!matrix_add(&state->x, &state->x, &state->temp1)) {
        return false;
    }

    /* 4. 协方差更新: P = (I - K * H) * P */
    /* 计算 K * H */
    if (!matrix_mul(&state->temp1, &state->K, &state->H)) {
        return false;
    }

    /* 计算 I - K * H */
    Matrix I;
    matrix_eye(&I, config->state_dim);
    if (!matrix_sub(&state->temp2, &I, &state->temp1)) {
        return false;
    }

    /* 计算 (I - K * H) * P */
    if (!matrix_mul(&state->P, &state->temp2, &state->P)) {
        return false;
    }

    return true;
}

/* ========== Joseph形式更新 ========== */

static bool ekf_joseph_update(EKF_State *state, const EKF_Config *config) {
    /* Joseph形式：P = (I - K*H) * P * (I - K*H)' + K * R * K' */

    /* 1. 计算新息协方差: S = H * P * H' + R */
    Matrix H_T;
    if (!matrix_transpose(&H_T, &state->H)) {
        return false;
    }

    /* H * P */
    if (!matrix_mul(&state->temp1, &state->H, &state->P)) {
        return false;
    }

    /* H * P * H' */
    if (!matrix_mul(&state->temp2, &state->temp1, &H_T)) {
        return false;
    }

    /* S = H * P * H' + R */
    if (!matrix_add(&state->S, &state->temp2, &config->R)) {
        return false;
    }

    /* 2. 计算卡尔曼增益: K = P * H' * S^(-1) */
    Matrix S_inv;
    if (!matrix_inverse(&S_inv, &state->S)) {
        return false;
    }

    /* P * H' */
    if (!matrix_mul(&state->temp1, &state->P, &H_T)) {
        return false;
    }

    /* K = P * H' * S^(-1) */
    if (!matrix_mul(&state->K, &state->temp1, &S_inv)) {
        return false;
    }

    /* 3. 状态更新: x = x + K * y */
    if (!matrix_mul(&state->temp1, &state->K, &state->y)) {
        return false;
    }

    if (!matrix_add(&state->x, &state->x, &state->temp1)) {
        return false;
    }

    /* 4. Joseph形式协方差更新 */
    /* 计算 I - K * H */
    Matrix I;
    matrix_eye(&I, config->state_dim);

    if (!matrix_mul(&state->temp1, &state->K, &state->H)) {
        return false;
    }

    Matrix I_KH;
    if (!matrix_sub(&I_KH, &I, &state->temp1)) {
        return false;
    }

    /* 计算 (I - K * H) * P */
    if (!matrix_mul(&state->temp1, &I_KH, &state->P)) {
        return false;
    }

    /* 计算 ((I - K * H) * P) * (I - K * H)' */
    Matrix I_KH_T;
    if (!matrix_transpose(&I_KH_T, &I_KH)) {
        return false;
    }

    if (!matrix_mul(&state->temp2, &state->temp1, &I_KH_T)) {
        return false;
    }

    /* 计算 K * R */
    if (!matrix_mul(&state->temp1, &state->K, &config->R)) {
        return false;
    }

    /* 计算 K * R * K' */
    Matrix K_T;
    if (!matrix_transpose(&K_T, &state->K)) {
        return false;
    }

    if (!matrix_mul(&state->temp1, &state->temp1, &K_T)) {
        return false;
    }

    /* 计算 P = (I - K*H) * P * (I - K*H)' + K * R * K' */
    if (!matrix_add(&state->P, &state->temp2, &state->temp1)) {
        return false;
    }

    return true;
}

/* ========== Student-t鲁棒更新 ========== */

static bool ekf_student_t_update(EKF_State *state, const EKF_Config *config) {
    /* Student-t更新：使用t分布替代高斯分布，对异常值更鲁棒 */

    /* 1. 计算新息协方差: S = H * P * H' + R */
    Matrix H_T;
    if (!matrix_transpose(&H_T, &state->H)) {
        return false;
    }

    /* H * P */
    if (!matrix_mul(&state->temp1, &state->H, &state->P)) {
        return false;
    }

    /* H * P * H' */
    if (!matrix_mul(&state->temp2, &state->temp1, &H_T)) {
        return false;
    }

    /* S = H * P * H' + R */
    if (!matrix_add(&state->S, &state->temp2, &config->R)) {
        return false;
    }

    /* 2. 计算马氏距离 */
    float d = ekf_mahalanobis_distance(state);

    /* 3. 计算Student-t权重 */
    float nu = config->student_t_nu;
    float delta = config->student_t_delta;
    float n = config->measurement_dim;

    /* w = (nu + n) / (nu + d^2/delta^2) */
    float d_normalized = d / delta;
    float weight = (nu + n) / (nu + d_normalized * d_normalized);

    /* 4. 调整噪声协方差 */
    /* R_scaled = R * weight */
    Matrix R_scaled;
    if (!matrix_scale(&R_scaled, &config->R, weight)) {
        return false;
    }

    /* 5. 使用调整后的噪声进行标准更新 */
    /* 重新计算新息协方差: S = H * P * H' + R_scaled */
    if (!matrix_add(&state->S, &state->temp2, &R_scaled)) {
        return false;
    }

    /* 计算卡尔曼增益 */
    Matrix S_inv;
    if (!matrix_inverse(&S_inv, &state->S)) {
        return false;
    }

    /* P * H' */
    if (!matrix_mul(&state->temp1, &state->P, &H_T)) {
        return false;
    }

    /* K = P * H' * S^(-1) */
    if (!matrix_mul(&state->K, &state->temp1, &S_inv)) {
        return false;
    }

    /* 状态更新 */
    if (!matrix_mul(&state->temp1, &state->K, &state->y)) {
        return false;
    }

    if (!matrix_add(&state->x, &state->x, &state->temp1)) {
        return false;
    }

    /* 协方差更新（Joseph形式） */
    Matrix I;
    matrix_eye(&I, config->state_dim);

    if (!matrix_mul(&state->temp1, &state->K, &state->H)) {
        return false;
    }

    Matrix I_KH;
    if (!matrix_sub(&I_KH, &I, &state->temp1)) {
        return false;
    }

    if (!matrix_mul(&state->temp1, &I_KH, &state->P)) {
        return false;
    }

    Matrix I_KH_T;
    if (!matrix_transpose(&I_KH_T, &I_KH)) {
        return false;
    }

    if (!matrix_mul(&state->temp2, &state->temp1, &I_KH_T)) {
        return false;
    }

    if (!matrix_mul(&state->temp1, &state->K, &R_scaled)) {
        return false;
    }

    Matrix K_T;
    if (!matrix_transpose(&K_T, &state->K)) {
        return false;
    }

    if (!matrix_mul(&state->temp1, &state->temp1, &K_T)) {
        return false;
    }

    if (!matrix_add(&state->P, &state->temp2, &state->temp1)) {
        return false;
    }

    return true;
}

/* ========== 自适应更新 ========== */

static bool ekf_adaptive_update(EKF_State *state, const EKF_Config *config) {
    /* 自适应EKF：基于新息序列的协方差匹配算法 */

    /* 1. 计算新息协方差: S = H * P * H' + R */
    Matrix H_T;
    if (!matrix_transpose(&H_T, &state->H)) return false;

    if (!matrix_mul(&state->temp1, &state->H, &state->P)) return false;
    if (!matrix_mul(&state->temp2, &state->temp1, &H_T)) return false;
    if (!matrix_add(&state->S, &state->temp2, &config->R)) return false;

    /* 2. 计算新息: y = z - H * x_pred */
    /* y 已在 ekf_update 中计算 */

    /* 3. 自适应调整R：基于新息的实际方差 */
    float y_val = state->y.data[0];  /* 一维情况 */
    float S_val = state->S.data[0];  /* 一维情况 */

    /* 计算标准化新息平方 */
    float innov_sq = y_val * y_val / (S_val + 1e-10f);

    /* 自适应因子：如果新息大，增大R */
    float alpha = config->adaptive_factor;
    float window = config->adaptive_window;

    /* R_adaptive = R * (1 + alpha * max(0, innov_sq - 1)) */
    float adaptive_factor = 1.0f + alpha * (innov_sq > 1.0f ? (innov_sq - 1.0f) : 0.0f);

    /* 限制自适应因子范围 */
    if (adaptive_factor > window) adaptive_factor = window;
    if (adaptive_factor < 0.1f) adaptive_factor = 0.1f;

    /* 调整后的R */
    Matrix R_adaptive;
    if (!matrix_scale(&R_adaptive, &config->R, adaptive_factor)) return false;

    /* 4. 使用调整后的R进行标准更新 */
    if (!matrix_add(&state->S, &state->temp2, &R_adaptive)) return false;

    Matrix S_inv;
    if (!matrix_inverse(&S_inv, &state->S)) return false;

    if (!matrix_mul(&state->temp1, &state->P, &H_T)) return false;
    if (!matrix_mul(&state->K, &state->temp1, &S_inv)) return false;

    /* 状态更新 */
    if (!matrix_mul(&state->temp1, &state->K, &state->y)) return false;
    if (!matrix_add(&state->x, &state->x, &state->temp1)) return false;

    /* 协方差更新（Joseph形式） */
    Matrix I;
    matrix_eye(&I, config->state_dim);

    if (!matrix_mul(&state->temp1, &state->K, &state->H)) return false;
    Matrix I_KH;
    if (!matrix_sub(&I_KH, &I, &state->temp1)) return false;
    if (!matrix_mul(&state->temp1, &I_KH, &state->P)) return false;

    Matrix I_KH_T;
    if (!matrix_transpose(&I_KH_T, &I_KH)) return false;
    if (!matrix_mul(&state->temp2, &state->temp1, &I_KH_T)) return false;

    if (!matrix_mul(&state->temp1, &state->K, &R_adaptive)) return false;
    Matrix K_T;
    if (!matrix_transpose(&K_T, &state->K)) return false;
    if (!matrix_mul(&state->temp1, &state->temp1, &K_T)) return false;
    if (!matrix_add(&state->P, &state->temp2, &state->temp1)) return false;

    return true;
}

/* ========== 辅助函数 ========== */

static float ekf_mahalanobis_distance(const EKF_State *state) {
    /* 计算马氏距离: d = sqrt(y' * S^(-1) * y) */

    Matrix S_inv;
    if (!matrix_inverse(&S_inv, &state->S)) {
        return 0.0f;
    }

    /* S^(-1) * y */
    Matrix temp;
    if (!matrix_mul(&temp, &S_inv, &state->y)) {
        return 0.0f;
    }

    /* y' * (S^(-1) * y) */
    float d_squared = 0.0f;
    for (uint8_t i = 0; i < state->y.rows; i++) {
        d_squared += state->y.data[i] * temp.data[i];
    }

    return sqrtf(fabsf(d_squared));
}

/* ========== 状态获取函数 ========== */

bool ekf_get_state(const EKF_State *state, Matrix *x) {
    if (state == NULL || x == NULL || !state->initialized) {
        return false;
    }
    return matrix_copy(x, &state->x);
}

bool ekf_get_covariance(const EKF_State *state, Matrix *P) {
    if (state == NULL || P == NULL || !state->initialized) {
        return false;
    }
    return matrix_copy(P, &state->P);
}

bool ekf_get_innovation(const EKF_State *state, Matrix *y) {
    if (state == NULL || y == NULL || !state->initialized) {
        return false;
    }
    return matrix_copy(y, &state->y);
}

bool ekf_get_kalman_gain(const EKF_State *state, Matrix *K) {
    if (state == NULL || K == NULL || !state->initialized) {
        return false;
    }
    return matrix_copy(K, &state->K);
}

void ekf_reset(EKF_State *state) {
    if (state != NULL) {
        state->initialized = false;
        state->step_count = 0;
    }
}

void ekf_print_state(const EKF_State *state) {
    if (state == NULL) {
        return;
    }

    printf("EKF State:\n");
    printf("  Initialized: %s\n", state->initialized ? "true" : "false");
    printf("  Step count: %u\n", state->step_count);

    if (state->initialized) {
        matrix_print(&state->x, "State (x)");
        matrix_print(&state->P, "Covariance (P)");
    }
}