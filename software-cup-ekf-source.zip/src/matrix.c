/**
 * @file matrix.c
 * @brief 矩阵运算库实现
 *
 * 实现零动态分配的矩阵运算，针对嵌入式环境优化
 *
 * @author 软件杯团队
 * @date 2026-06-11
 */

#include "matrix.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* 内部辅助宏 */
#define MATRIX_INDEX(mat, row, col) ((row) * (mat)->stride + (col))
#define MATRIX_VALID_INDEX(mat, row, col) \
    ((row) < (mat)->rows && (col) < (mat)->cols)

/* ========== 矩阵创建和初始化 ========== */

bool matrix_init(Matrix *mat, uint8_t rows, uint8_t cols) {
    if (mat == NULL || rows == 0 || cols == 0 ||
        rows > MATRIX_MAX_ROWS || cols > MATRIX_MAX_COLS) {
        return false;
    }

    mat->rows = rows;
    mat->cols = cols;
    mat->stride = cols;  // 行优先存储
    memset(mat->data, 0, sizeof(float) * rows * cols);

    return true;
}

bool matrix_zeros(Matrix *mat, uint8_t rows, uint8_t cols) {
    return matrix_init(mat, rows, cols);
}

bool matrix_eye(Matrix *mat, uint8_t size) {
    if (!matrix_init(mat, size, size)) {
        return false;
    }

    for (uint8_t i = 0; i < size; i++) {
        mat->data[MATRIX_INDEX(mat, i, i)] = 1.0f;
    }

    return true;
}

bool matrix_from_array(Matrix *mat, uint8_t rows, uint8_t cols, const float *data) {
    if (mat == NULL || data == NULL || rows == 0 || cols == 0 ||
        rows > MATRIX_MAX_ROWS || cols > MATRIX_MAX_COLS) {
        return false;
    }

    mat->rows = rows;
    mat->cols = cols;
    mat->stride = cols;
    memcpy(mat->data, data, sizeof(float) * rows * cols);

    return true;
}

bool matrix_copy(Matrix *dst, const Matrix *src) {
    if (dst == NULL || src == NULL) {
        return false;
    }

    dst->rows = src->rows;
    dst->cols = src->cols;
    dst->stride = src->stride;
    memcpy(dst->data, src->data, sizeof(float) * src->rows * src->cols);

    return true;
}

/* ========== 基本矩阵运算 ========== */

bool matrix_add(Matrix *result, const Matrix *a, const Matrix *b) {
    if (result == NULL || a == NULL || b == NULL) {
        return false;
    }

    if (a->rows != b->rows || a->cols != b->cols) {
        return false;
    }

    result->rows = a->rows;
    result->cols = a->cols;
    result->stride = a->cols;

    for (uint8_t i = 0; i < a->rows; i++) {
        for (uint8_t j = 0; j < a->cols; j++) {
            result->data[MATRIX_INDEX(result, i, j)] =
                a->data[MATRIX_INDEX(a, i, j)] + b->data[MATRIX_INDEX(b, i, j)];
        }
    }

    return true;
}

bool matrix_sub(Matrix *result, const Matrix *a, const Matrix *b) {
    if (result == NULL || a == NULL || b == NULL) {
        return false;
    }

    if (a->rows != b->rows || a->cols != b->cols) {
        return false;
    }

    result->rows = a->rows;
    result->cols = a->cols;
    result->stride = a->cols;

    for (uint8_t i = 0; i < a->rows; i++) {
        for (uint8_t j = 0; j < a->cols; j++) {
            result->data[MATRIX_INDEX(result, i, j)] =
                a->data[MATRIX_INDEX(a, i, j)] - b->data[MATRIX_INDEX(b, i, j)];
        }
    }

    return true;
}

bool matrix_mul(Matrix *result, const Matrix *a, const Matrix *b) {
    if (result == NULL || a == NULL || b == NULL) {
        return false;
    }

    if (a->cols != b->rows) {
        return false;
    }

    result->rows = a->rows;
    result->cols = b->cols;
    result->stride = b->cols;

    // 初始化结果为0
    memset(result->data, 0, sizeof(float) * result->rows * result->cols);

    // 矩阵乘法
    for (uint8_t i = 0; i < a->rows; i++) {
        for (uint8_t k = 0; k < a->cols; k++) {
            float a_ik = a->data[MATRIX_INDEX(a, i, k)];
            for (uint8_t j = 0; j < b->cols; j++) {
                result->data[MATRIX_INDEX(result, i, j)] +=
                    a_ik * b->data[MATRIX_INDEX(b, k, j)];
            }
        }
    }

    return true;
}

bool matrix_scale(Matrix *result, const Matrix *mat, float scalar) {
    if (result == NULL || mat == NULL) {
        return false;
    }

    result->rows = mat->rows;
    result->cols = mat->cols;
    result->stride = mat->cols;

    for (uint8_t i = 0; i < mat->rows; i++) {
        for (uint8_t j = 0; j < mat->cols; j++) {
            result->data[MATRIX_INDEX(result, i, j)] =
                mat->data[MATRIX_INDEX(mat, i, j)] * scalar;
        }
    }

    return true;
}

bool matrix_transpose(Matrix *result, const Matrix *mat) {
    if (result == NULL || mat == NULL) {
        return false;
    }

    result->rows = mat->cols;
    result->cols = mat->rows;
    result->stride = mat->rows;

    for (uint8_t i = 0; i < mat->rows; i++) {
        for (uint8_t j = 0; j < mat->cols; j++) {
            result->data[MATRIX_INDEX(result, j, i)] =
                mat->data[MATRIX_INDEX(mat, i, j)];
        }
    }

    return true;
}

/* ========== 高级矩阵运算 ========== */

bool matrix_inverse(Matrix *result, const Matrix *mat) {
    if (result == NULL || mat == NULL || !matrix_is_square(mat)) {
        return false;
    }

    uint8_t n = mat->rows;

    // 创建增广矩阵 [A | I]
    Matrix augmented;
    augmented.rows = n;
    augmented.cols = n * 2;
    augmented.stride = n * 2;

    // 填充增广矩阵
    for (uint8_t i = 0; i < n; i++) {
        for (uint8_t j = 0; j < n; j++) {
            augmented.data[MATRIX_INDEX(&augmented, i, j)] =
                mat->data[MATRIX_INDEX(mat, i, j)];
        }
        augmented.data[MATRIX_INDEX(&augmented, i, n + i)] = 1.0f;
    }

    // 高斯-约旦消元
    for (uint8_t i = 0; i < n; i++) {
        // 寻找主元
        float max_val = fabsf(augmented.data[MATRIX_INDEX(&augmented, i, i)]);
        uint8_t max_row = i;

        for (uint8_t k = i + 1; k < n; k++) {
            float val = fabsf(augmented.data[MATRIX_INDEX(&augmented, k, i)]);
            if (val > max_val) {
                max_val = val;
                max_row = k;
            }
        }

        // 检查矩阵是否奇异
        if (max_val < 1e-10f) {
            return false;
        }

        // 交换行
        if (max_row != i) {
            for (uint8_t j = 0; j < augmented.cols; j++) {
                float temp = augmented.data[MATRIX_INDEX(&augmented, i, j)];
                augmented.data[MATRIX_INDEX(&augmented, i, j)] =
                    augmented.data[MATRIX_INDEX(&augmented, max_row, j)];
                augmented.data[MATRIX_INDEX(&augmented, max_row, j)] = temp;
            }
        }

        // 缩放主元行
        float pivot = augmented.data[MATRIX_INDEX(&augmented, i, i)];
        for (uint8_t j = 0; j < augmented.cols; j++) {
            augmented.data[MATRIX_INDEX(&augmented, i, j)] /= pivot;
        }

        // 消元
        for (uint8_t k = 0; k < n; k++) {
            if (k != i) {
                float factor = augmented.data[MATRIX_INDEX(&augmented, k, i)];
                for (uint8_t j = 0; j < augmented.cols; j++) {
                    augmented.data[MATRIX_INDEX(&augmented, k, j)] -=
                        factor * augmented.data[MATRIX_INDEX(&augmented, i, j)];
                }
            }
        }
    }

    // 提取逆矩阵
    result->rows = n;
    result->cols = n;
    result->stride = n;

    for (uint8_t i = 0; i < n; i++) {
        for (uint8_t j = 0; j < n; j++) {
            result->data[MATRIX_INDEX(result, i, j)] =
                augmented.data[MATRIX_INDEX(&augmented, i, n + j)];
        }
    }

    return true;
}

bool matrix_determinant(float *result, const Matrix *mat) {
    if (result == NULL || mat == NULL || !matrix_is_square(mat)) {
        return false;
    }

    uint8_t n = mat->rows;

    // 特殊情况处理
    if (n == 1) {
        *result = mat->data[0];
        return true;
    }

    if (n == 2) {
        *result = mat->data[0] * mat->data[3] - mat->data[1] * mat->data[2];
        return true;
    }

    // 使用LU分解计算行列式
    Matrix L, U, P;
    if (!matrix_lu(&L, &U, &P, mat)) {
        return false;
    }

    // 行列式等于U的对角线元素之积
    float det = 1.0f;
    for (uint8_t i = 0; i < n; i++) {
        det *= U.data[MATRIX_INDEX(&U, i, i)];
    }

    // 考虑置换矩阵的符号
    // 计算置换的逆序数
    int sign = 1;
    for (uint8_t i = 0; i < n; i++) {
        for (uint8_t j = i + 1; j < n; j++) {
            // 找到P中第i行和第j行的非零元素位置
            uint8_t pos_i = 0, pos_j = 0;
            for (uint8_t k = 0; k < n; k++) {
                if (fabsf(P.data[MATRIX_INDEX(&P, i, k)] - 1.0f) < 1e-6f) {
                    pos_i = k;
                }
                if (fabsf(P.data[MATRIX_INDEX(&P, j, k)] - 1.0f) < 1e-6f) {
                    pos_j = k;
                }
            }
            if (pos_i > pos_j) {
                sign = -sign;
            }
        }
    }

    *result = det * sign;
    return true;
}

bool matrix_trace(float *result, const Matrix *mat) {
    if (result == NULL || mat == NULL || !matrix_is_square(mat)) {
        return false;
    }

    float sum = 0.0f;
    for (uint8_t i = 0; i < mat->rows; i++) {
        sum += mat->data[MATRIX_INDEX(mat, i, i)];
    }

    *result = sum;
    return true;
}

/* ========== 特殊矩阵运算 ========== */

bool matrix_cholesky(Matrix *L, const Matrix *mat) {
    if (L == NULL || mat == NULL || !matrix_is_square(mat)) {
        return false;
    }

    uint8_t n = mat->rows;

    // 检查是否对称
    if (!matrix_is_symmetric(mat)) {
        return false;
    }

    // 初始化L为零矩阵
    matrix_zeros(L, n, n);

    // Cholesky分解
    for (uint8_t i = 0; i < n; i++) {
        for (uint8_t j = 0; j <= i; j++) {
            float sum = 0.0f;

            if (i == j) {
                // 对角线元素
                for (uint8_t k = 0; k < j; k++) {
                    float l_jk = L->data[MATRIX_INDEX(L, j, k)];
                    sum += l_jk * l_jk;
                }

                float val = mat->data[MATRIX_INDEX(mat, j, j)] - sum;
                if (val <= 0.0f) {
                    return false;  // 非正定矩阵
                }
                L->data[MATRIX_INDEX(L, j, j)] = sqrtf(val);
            } else {
                // 非对角线元素
                for (uint8_t k = 0; k < j; k++) {
                    sum += L->data[MATRIX_INDEX(L, i, k)] *
                           L->data[MATRIX_INDEX(L, j, k)];
                }
                L->data[MATRIX_INDEX(L, i, j)] =
                    (mat->data[MATRIX_INDEX(mat, i, j)] - sum) /
                    L->data[MATRIX_INDEX(L, j, j)];
            }
        }
    }

    return true;
}

bool matrix_lu(Matrix *L, Matrix *U, Matrix *P, const Matrix *mat) {
    if (L == NULL || U == NULL || P == NULL || mat == NULL ||
        !matrix_is_square(mat)) {
        return false;
    }

    uint8_t n = mat->rows;

    // 初始化P为单位矩阵
    matrix_eye(P, n);

    // 复制mat到U
    matrix_copy(U, mat);

    // 初始化L为单位矩阵
    matrix_eye(L, n);

    // LU分解
    for (uint8_t i = 0; i < n; i++) {
        // 寻找主元
        float max_val = fabsf(U->data[MATRIX_INDEX(U, i, i)]);
        uint8_t max_row = i;

        for (uint8_t k = i + 1; k < n; k++) {
            float val = fabsf(U->data[MATRIX_INDEX(U, k, i)]);
            if (val > max_val) {
                max_val = val;
                max_row = k;
            }
        }

        // 交换行
        if (max_row != i) {
            // 交换U的行
            for (uint8_t j = 0; j < n; j++) {
                float temp = U->data[MATRIX_INDEX(U, i, j)];
                U->data[MATRIX_INDEX(U, i, j)] = U->data[MATRIX_INDEX(U, max_row, j)];
                U->data[MATRIX_INDEX(U, max_row, j)] = temp;
            }

            // 交换L的行（只交换已计算的部分）
            for (uint8_t j = 0; j < i; j++) {
                float temp = L->data[MATRIX_INDEX(L, i, j)];
                L->data[MATRIX_INDEX(L, i, j)] = L->data[MATRIX_INDEX(L, max_row, j)];
                L->data[MATRIX_INDEX(L, max_row, j)] = temp;
            }

            // 交换P的行
            for (uint8_t j = 0; j < n; j++) {
                float temp = P->data[MATRIX_INDEX(P, i, j)];
                P->data[MATRIX_INDEX(P, i, j)] = P->data[MATRIX_INDEX(P, max_row, j)];
                P->data[MATRIX_INDEX(P, max_row, j)] = temp;
            }
        }

        // 检查主元是否为0
        if (fabsf(U->data[MATRIX_INDEX(U, i, i)]) < 1e-10f) {
            return false;
        }

        // 计算L和U
        for (uint8_t j = i + 1; j < n; j++) {
            L->data[MATRIX_INDEX(L, j, i)] =
                U->data[MATRIX_INDEX(U, j, i)] / U->data[MATRIX_INDEX(U, i, i)];

            for (uint8_t k = i; k < n; k++) {
                U->data[MATRIX_INDEX(U, j, k)] -=
                    L->data[MATRIX_INDEX(L, j, i)] * U->data[MATRIX_INDEX(U, i, k)];
            }
        }
    }

    return true;
}

/* ========== 矩阵元素访问 ========== */

float matrix_get(const Matrix *mat, uint8_t row, uint8_t col) {
    if (mat == NULL || !MATRIX_VALID_INDEX(mat, row, col)) {
        return 0.0f;
    }
    return mat->data[MATRIX_INDEX(mat, row, col)];
}

void matrix_set(Matrix *mat, uint8_t row, uint8_t col, float value) {
    if (mat != NULL && MATRIX_VALID_INDEX(mat, row, col)) {
        mat->data[MATRIX_INDEX(mat, row, col)] = value;
    }
}

bool matrix_diag(float *result, const Matrix *mat) {
    if (result == NULL || mat == NULL || !matrix_is_square(mat)) {
        return false;
    }

    for (uint8_t i = 0; i < mat->rows; i++) {
        result[i] = mat->data[MATRIX_INDEX(mat, i, i)];
    }

    return true;
}

/* ========== 矩阵视图操作 ========== */

bool matrix_view_create(MatrixView *view, const Matrix *mat,
                       uint8_t row_start, uint8_t col_start,
                       uint8_t rows, uint8_t cols) {
    if (view == NULL || mat == NULL) {
        return false;
    }

    if (row_start + rows > mat->rows || col_start + cols > mat->cols) {
        return false;
    }

    view->data = (float *)&mat->data[MATRIX_INDEX(mat, row_start, col_start)];
    view->rows = rows;
    view->cols = cols;
    view->stride = mat->stride;

    return true;
}

/* ========== 工具函数 ========== */

void matrix_print(const Matrix *mat, const char *name) {
    if (mat == NULL) {
        return;
    }

    if (name != NULL) {
        printf("%s (%dx%d):\n", name, mat->rows, mat->cols);
    }

    for (uint8_t i = 0; i < mat->rows; i++) {
        printf("[");
        for (uint8_t j = 0; j < mat->cols; j++) {
            printf("%8.4f", mat->data[MATRIX_INDEX(mat, i, j)]);
            if (j < mat->cols - 1) {
                printf(", ");
            }
        }
        printf("]\n");
    }
    printf("\n");
}

bool matrix_is_square(const Matrix *mat) {
    if (mat == NULL) {
        return false;
    }
    return mat->rows == mat->cols;
}

bool matrix_is_symmetric(const Matrix *mat) {
    if (mat == NULL || !matrix_is_square(mat)) {
        return false;
    }

    for (uint8_t i = 0; i < mat->rows; i++) {
        for (uint8_t j = i + 1; j < mat->cols; j++) {
            float diff = fabsf(mat->data[MATRIX_INDEX(mat, i, j)] -
                              mat->data[MATRIX_INDEX(mat, j, i)]);
            if (diff > 1e-6f) {
                return false;
            }
        }
    }

    return true;
}

bool matrix_dims_match(const Matrix *a, const Matrix *b) {
    if (a == NULL || b == NULL) {
        return false;
    }
    return (a->rows == b->rows) && (a->cols == b->cols);
}